mongo  --host localhost:27018 <<EOF
sh.addShard("rs0/192.168.50.3:27017")
sh.addShard("rs1/192.168.50.6:27017")
sh.enableSharding("newdb")
use newdb
db.addresses.ensureIndex({ restaurant_id: 1 }, { unique: true })
sh.shardCollection("newdb.addresses", { restaurant_id: 1 } )
exit
EOF
