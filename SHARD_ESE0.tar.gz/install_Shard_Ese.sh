sudo mkdir -p /home/enzo/Download
cp -p add_hosts.sh go_mongoimp_repl.sh Start_cfg.sh Start_rs0.sh Start_rs1.sh Start_shard.sh mongod.conf.ese4 mongos.conf vagrant-centos_primer-dataset.json /home/enzo/Download
virtualbox &
vagrant up
