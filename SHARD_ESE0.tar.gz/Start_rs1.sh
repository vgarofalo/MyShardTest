mongo <<EOF
rs.initiate({
  _id: "rs1",
  members: [
    { _id : 0, host : "192.168.50.6:27017" },
    { _id : 1, host : "192.168.50.7:27017" },
    { _id : 2, host : "192.168.50.8:27017" }
  ]
})
exit
EOF
