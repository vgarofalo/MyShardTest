mongo <<EOF
rs.initiate({
  _id: "rs0",
  members: [
    { _id : 0, host : "192.168.50.3:27017" },
    { _id : 1, host : "192.168.50.4:27017" },
    { _id : 2, host : "192.168.50.5:27017" }
  ]
})
exit
EOF
