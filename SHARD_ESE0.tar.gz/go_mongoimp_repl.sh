mongo --host "rs0/192.168.50.3,192.168.50.4,192.168.50.5:27017" <<EOF
use newdb
exit
EOF

cd /vagrant
mongoimport --host "rs0/192.168.50.3,192.168.50.4,192.168.50.5:27017" -v --db newdb --collection addresses --file vagrant-centos_primer-dataset.json
