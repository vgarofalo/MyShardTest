a=$1
b=$2
c=$3
echo '   bindIp: ${a}'		>> /etc/mongod.conf
