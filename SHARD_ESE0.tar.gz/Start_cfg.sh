mongo <<EOF
rs.initiate({
  _id: "cfg",
  configsvr: true,
  members: [
    { _id : 0, host : "192.168.50.9:27017" },
    { _id : 1, host : "192.168.50.10:27017" },
    { _id : 2, host : "192.168.50.11:27017" }
  ]
})
exit
EOF
